package homework2;

public class SoldierWithHeritance extends Person {

	private String weapon;

	public SoldierWithHeritance(String name, int age, String weapon) {
		super(name, age); // Constructor from superclass
		this.weapon = weapon;
	}

	@Override
	public String doActivity() {
		
		
		// TODO Auto-generated method stub
		return "Im using my " + this.weapon;
	}

}
