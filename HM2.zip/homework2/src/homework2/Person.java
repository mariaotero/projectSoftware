package homework2;

public abstract class Person {

	private String name;
	private int age;
	
	
	//Constructor 1
	public Person() {
		
		this.name = "Lulu";
		this.age = 25;

	}

	//Constructor 2
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String toString() {
		return "Hi,my name is " + name + " and im " + age + " old.";
	}
	
	public void introduceOneSelf() {
		System.out.println(this.toString());
	}
	
	
	public abstract String doActivity();
	
	public void birthday() {
		this.age=this.age+1;
		System.out.println("Happy Birthday, today im " + age + " years old!!!");
	}
	
	
}
