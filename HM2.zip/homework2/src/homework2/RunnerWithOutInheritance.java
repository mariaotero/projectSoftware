package homework2;

public class RunnerWithOutInheritance {

	private String name;
	private int age;
	private double runningDistance;
	
	public RunnerWithOutInheritance(String name, int age, double runningDistance) {
		this.name = name;
		this.age = age;
		this.runningDistance = runningDistance;
	}
	
	public String doActivity() {
		return "Running a distance of "+runningDistance+" km";
	}
	
	//Duplicated code 
	
	public void birthday() {
		this.age=this.age+1;
		System.out.println("Happy Birthday, today im " + age + " years old!!!");
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String toString() {
		return "Hi,my name is " + name + " and im " + age + " old.";
	}
	
	public void introduceOneSelf() {
		System.out.println(this.toString());
	}
	
}
