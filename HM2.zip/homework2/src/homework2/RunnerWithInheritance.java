package homework2;

public class RunnerWithInheritance extends Person {

	private double runningDistance;

	public RunnerWithInheritance(String name, int age, double runningDistance) {
		super(name, age); // Constructor from superclass
		this.runningDistance = runningDistance;
	}

	@Override
	public String doActivity() {

		// TODO Auto-generated method stub
		return "Running a distance of " + runningDistance + " km";

	}

}
