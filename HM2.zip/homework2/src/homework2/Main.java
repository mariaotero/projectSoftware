package homework2;

public class Main {

	public static void main(String[] args) {

		//Now this lines doesnt compile because the class Person is an abstract class.
		
//		Person p1 = new Person("Joan", 84);
//		Person p2 = new Person("Maria", 32);
//		Person p3 = new Person("Osman", 12);
//		Person p4 = new Person();
//
//		p1.introduceOneSelf();
//		p2.introduceOneSelf();
//		p3.introduceOneSelf();
//		p4.introduceOneSelf();

		
		RunnerWithInheritance runner1 = new RunnerWithInheritance("Paco", 22, 12);
		RunnerWithOutInheritance runner2 = new RunnerWithOutInheritance("Paco", 22, 12);
		
		
		runner1.introduceOneSelf();
		runner2.introduceOneSelf();
		
		runner1.birthday();
		runner2.birthday();
		
		System.out.println("Runner 1: "+runner1.doActivity());
		System.out.println("Runner 2: "+runner2.doActivity());
		
		
		SoldierWithHeritance soldier = new SoldierWithHeritance("Osman", 36, "sword");
		
		soldier.introduceOneSelf();
		soldier.birthday();
		System.out.println("Soldier: "+soldier.doActivity());
		
		
		
	}

}
